Contribute
==========


Help
----

-  Open a new `issue`_ if you encounter a problem.
-  Or ping **@localhuman** or **@metachris** on the `NEO Slack`_.
-  Pull requests are welcome. New features, writing tests and
   documentation are all needed.

Donations
---------

Accepted at Neo address **ATEMNPSjRVvsXmaJW4ZYJBSVuJ6uR2mjQU**.

.. _issue: https://github.com/CityOfZion/neo-python/issues/new
.. _NEO Slack: https://join.slack.com/t/neoblockchainteam/shared_invite/MjE3ODMxNDUzMDE1LTE1MDA4OTY3NDQtNTMwM2MyMTc2NA
