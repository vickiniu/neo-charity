Tests
-----

Run tests with the following command

.. code-block:: sh

    python -m unittest discover neo