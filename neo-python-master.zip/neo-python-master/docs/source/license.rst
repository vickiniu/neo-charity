License
-------

-  Open-source `MIT`_.
-  Main author is **localhuman** [ https://github.com/localhuman ].

.. _MIT: https://github.com/CityOfZion/neo-python/blob/master/LICENSE.md
