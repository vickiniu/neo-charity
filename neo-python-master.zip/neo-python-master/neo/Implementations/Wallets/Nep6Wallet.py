from neo.Wallets.Wallet import Wallet

# class UserWallet(Wallet):
